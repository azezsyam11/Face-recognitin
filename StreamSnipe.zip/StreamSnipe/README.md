# 🎯 StreamSnipe - تطبيق مراقبة البث

## خطوات تشغيل التطبيق وبناء APK

### المتطلبات
- Node.js (تحميل من nodejs.org)
- حساب على expo.dev (مجاني)

---

### الخطوة 1: تثبيت المتطلبات
```bash
npm install -g @expo/eas-cli
npm install
```

### الخطوة 2: تسجيل الدخول في Expo
```bash
eas login
```

### الخطوة 3: بناء APK
```bash
eas build -p android --profile preview
```

سيعطيك رابط لتحميل APK مباشرة بعد 5-10 دقائق ✅

---

### للتشغيل المحلي (بدون APK)
```bash
npm install
npx expo start
```
ثم امسح QR Code بتطبيق **Expo Go** على هاتفك.

---

## المميزات
- 🎮 مراقبة Twitch / YouTube / TikTok
- 🎯 رصد كلمات في الشات
- 🔔 تنبيهات فورية
- 👁 تتبع عدد المشاهدين
- 📋 سجل الأحداث
